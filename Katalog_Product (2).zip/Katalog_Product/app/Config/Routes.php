<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/about', 'Home::index');
$routes->get('/materials', 'Materials::index');

// Menampilkan daftar pesanan
$routes->get('/order', 'OrderController::index');
$routes->get('/order/create', 'Order::create');
$routes->post('/order/store', 'OrderController::store');
$routes->get('product/(:num)', 'Product::showProduct/$1');
$routes->get('materials/(:num)', 'Materials::detail/$1');

$routes->get('/order/create', 'OrderController::create'); // Mengarahkan ke OrderController::create

// Menangani pengeditan pesanan
// $routes->get('/order/edit/(:num)', 'OrderController::edit/$1'); // Perbarui rute ke OrderController::edit

// $routes->post('/order/update/(:num)', 'Order::update/$1');

$routes->get('/order/edit/(:num)', 'OrderController::edit/$1');
$routes->post('/order/update/(:num)', 'OrderController::update/$1');


// Menangani penghapusan pesanan
$routes->get('/order/delete/(:num)', 'OrderController::delete/$1');

$routes->group('api', function ($routes) {
    $routes->post('order', 'OrderController::create');
});
