<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Upload extends BaseConfig
{
    public $tempPath = WRITEPATH . 'uploads/'; // Direktori tempat file akan disimpan

    // Batasan ukuran file dalam kilobyte (KB)
    public $maxSize = 102400; // 10MB

    // Tipe file yang diizinkan untuk diunggah
    public $allowedTypes = 'gif|jpg|png';

    // Nama file yang diunggah akan diacak (true) atau tidak (false)
    public $encryptName = true;

    // Mengganti nama file yang sudah ada dengan nama baru jika true
    public $overwrite = false;

    // Batasan lebar gambar dalam piksel
    public $maxWidth = 0;

    // Batasan tinggi gambar dalam piksel
    public $maxHeight = 0;

    // Menjaga file asli setelah proses resize (true) atau menghapusnya (false)
    public $keepOriginalImage = true;

    // Jika dinyatakan, maka proporsi gambar akan dijaga sesuai dengan ratio yang ditentukan
    // Contoh: '16:9', '4:3', dll.
    public $imageRatio = '';

    // Folder untuk menyimpan file sementara selama proses upload
    public $tempUploadFolder = WRITEPATH . 'uploads/';

    // Memungkinkan atau tidak untuk memindahkan file yang diunggah
    // ke direktori yang disebutkan di $uploadPath
    public $autoProcess = true;

    // Direktori tempat file akan disimpan setelah diunggah
    public $uploadPath = WRITEPATH . 'uploads/';

    // Jika diatur ke true, sistem akan mencoba
    // untuk membuat direktori yang tidak ada.
    public $createUploadPath = true;

    // Mencoba mempertahankan ekstensi file asli saat diubah
    // menjadi nama yang aman
    public $preserveExtension = true;

    // Mencoba mengecek tipe MIME nyata oleh server
    // dan memastikan bahwa tipe file tersebut aman untuk diunggah
    public $checkMime = true;

    // Mencoba memastikan file yang diunggah
    // benar-benar adalah gambar
    public $isImage = true;
}
