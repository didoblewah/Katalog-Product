<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Order extends Controller
{
    public function create()
    {
        return view('static/create'); // Assuming 'static' is the folder and 'create.php' is the view file
    }
}