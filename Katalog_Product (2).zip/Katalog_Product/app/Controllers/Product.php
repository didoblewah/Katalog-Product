<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Product extends BaseController
{
    public function index()
    {
        // Data produk
        $data['products'] = [
            [
                'image' => 'gambar1.jpg',
                'description' => 'Deskripsi singkat produk 1',
                'link' => 'https://link-produk1.com'
            ],
            [
                'image' => 'gambar2.jpg',
                'description' => 'Deskripsi singkat produk 2',
                'link' => 'https://link-produk2.com'
            ],
            [
                'image' => 'gambar3.jpg',
                'description' => 'Deskripsi singkat produk 3',
                'link' => 'https://link-produk3.com'
            ]
        ];

        // Tambahkan logika untuk menampilkan halaman produk di sini
        return view('static/products', $data);
    }
}
