<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Materials extends BaseController
{
    public function index()
    {
        // Data logo
        $data['logo'] = 'logo blue.png'; // Asumsi hanya satu logo
        
        // Data produk
        $data['products'] = [
            [
                'image' => 'kainn1.png',
                'name' => 'Combed Cotton.',
                'description' => 'Deskripsi singkat produk 1',
                'link' => base_url('materials/1') // Mengarahkan ke halaman detail material
            ],
            [
                'image' => 'kain2.png',
                'name' => 'Bamboo Cotton.',
                'description' => 'Deskripsi singkat produk 2',
                'link' => base_url('materials/2')
            ],
            [
                'image' => 'kain3.png',
                'name' => 'Canvas.',
                'description' => 'Deskripsi singkat produk 3',
                'link' => base_url('materials/3')
            ],
            [
                'image' => 'kain4.png',
                'name' => 'Flannel Cotton',
                'description' => 'Deskripsi singkat produk 4',
                'link' => base_url('materials/4')
            ],
        ];

        return view('static/materials', $data);
    }

    public function detail($id)
    {
        // Di sini Anda dapat mengambil data produk berdasarkan ID dari model (jika perlu)
        // Misalnya, menggunakan model untuk mengambil data dari database
        // Jika tidak perlu, Anda dapat langsung melewatkan data ke view seperti contoh di bawah ini

        // Mendefinisikan data produk berdasarkan id
        $products = [
            1 => [
                'id' => 1,
                'name' => 'Combed Cotton',
                'image' => 'combed.png',
                'description' => 'Deskripsi singkat produk 1.'
            ],
            2 => [
                'id' => 2,
                'name' => 'Bamboo Cotton',
                'image' => 'bamboo.png',
                'description' => 'Deskripsi singkat produk 2.'
            ],
            3 => [
                'id' => 3,
                'name' => 'Canvas',
                'image' => 'canvas.png',
                'description' => 'Deskripsi singkat produk 3.'
            ],
            4 => [
                'id' => 4,
                'name' => 'Flannel Cotton',
                'image' => 'flannel.png',
                'description' => 'Deskripsi singkat produk 4.'
            ]
        ];

        // Periksa apakah id produk ada dalam daftar
        if (array_key_exists($id, $products)) {
            // Jika ya, kirim data produk ke view
            $data['product'] = $products[$id];
            return view('static/materialdetail', $data);
        } else {
            // Jika tidak, tampilkan halaman 404
            return view('errors/html/error_404');
        }
    }
}