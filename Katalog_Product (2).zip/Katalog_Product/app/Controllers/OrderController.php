<?php

namespace App\Controllers;

use App\Models\OrderModel;
use CodeIgniter\Controller;

class OrderController extends Controller
{
    protected $orderModel;

    public function __construct()
    {
        $this->orderModel = new OrderModel();
    }

    public function index()
    {
        $data['orders'] = $this->orderModel->findAll();
        return view('static/vieworder', $data);
    }

    public function store()
    {
        $validationRules = [
            'product' => 'required',
            'material' => 'required',
            'quantity' => 'required|numeric',
            'design' => 'uploaded[design]|max_size[design,1024]|is_image[design]'
        ];

        if (!$this->validate($validationRules)) {
            return redirect()->back()->withInput()->with('error', 'Harap isi semua kolom dengan benar.');
        }

        $design = $this->request->getFile('design');

        if ($design->isValid() && !$design->hasMoved()) {
            $newName = $design->getRandomName();
            if (!$design->move(WRITEPATH . 'uploads', $newName)) {
                return redirect()->back()->withInput()->with('error', 'Gagal memindahkan berkas yang diunggah.');
            }
        } else {
            return redirect()->back()->withInput()->with('error', 'Gagal mengunggah desain. Silakan coba lagi.');
        }

        $data = [
            'product_name' => $this->request->getPost('product'),
            'material' => $this->request->getPost('material'),
            'quantity' => $this->request->getPost('quantity'),
            'design' => $newName
        ];

        $this->orderModel->insert($data);

        return redirect()->to('/order/create')->with('success', 'Pesanan berhasil dibuat.');
    }

    public function edit($id)
    {
        $data['order'] = $this->orderModel->find($id);
        return view('static/edit', $data);
    }

    public function update($id)
    {
        $validationRules = [
            'product_name' => 'required',
            'material' => 'required',
            'quantity' => 'required|numeric',
            'design' => 'permit_empty|uploaded[design]|max_size[design,1024]|is_image[design]'
        ];

        if (!$this->validate($validationRules)) {
            echo "<pre>";
            print_r($this->validator->getErrors());
            echo "</pre>";
            return redirect()->back()->withInput()->with('error', 'Harap isi semua kolom dengan benar.');
        }

        $data = [
            'product_name' => $this->request->getPost('product_name'),
            'material' => $this->request->getPost('material'),
            'quantity' => $this->request->getPost('quantity')
        ];

        $design = $this->request->getFile('design');

        if ($design && $design->isValid() && !$design->hasMoved()) {
            $newName = $design->getRandomName();
            if (!$design->move(WRITEPATH . 'uploads', $newName)) {
                return redirect()->back()->withInput()->with('error', 'Gagal memindahkan berkas yang diunggah.');
            }
            $data['design'] = $newName;
        }

        $this->orderModel->update($id, $data);

        return redirect()->to('/order')->with('success', 'Pesanan berhasil diperbarui.');
    }

    public function delete($id)
    {
        $this->orderModel->delete($id);
        return redirect()->to('/order')->with('success', 'Pesanan berhasil dihapus.');
    }

}
