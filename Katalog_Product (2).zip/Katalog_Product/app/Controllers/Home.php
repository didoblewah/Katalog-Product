<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Home extends BaseController
{
    public function index()
    {
        
        // Data logo
        $data['logo'] = 'logo blue.png'; // Asumsi hanya satu logo
        
        // Data carousel
        $data['carouselImages'] = [
            'konveksi.png',
            'konveksi2.png',
            'konveksi3.png'
        ];

        // Data produk
        $data['products'] = [
            [
                'image' => 'kaos1.jpg',
                'name' => 'T-shirt Printing',
                'description' => 'Deskripsi singkat produk 1',
                'link' => base_url('product/1')
            ],
            [
                'image' => 'Kemeja.jpg',
                'name' => 'Workshirt',
                'description' => 'Deskripsi singkat produk 2',
                'link' => base_url('product/2')
            ],
            [
                'image' => 'kaos2.jpg',
                'name' => 'T-shirt',
                'description' => 'Deskripsi singkat produk 3',
                'link' => base_url('product/3')
            ],
        ];
        return view('static/home', $data);
    }
}
