<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\OrderModel;

class Order extends BaseController
{
    protected $orderModel;

    public function __construct()
    {
        $this->orderModel = new OrderModel();
    }

    public function index()
    {
        // Mendapatkan semua data pesanan dari database
        $data['orders'] = $this->orderModel->findAll();

        return view('static/index', $data);
    }

    public function create()
    {
        return view('static/create');
    }

    public function store()
    {
        // Validasi input jika diperlukan
        $validationRules = [
            'product' => 'required',
            'material' => 'required',
            'quantity' => 'required|numeric',
            'design' => 'uploaded[design]|max_size[design,1024]|is_image[design]'
        ];

        if (!$this->validate($validationRules)) {
            // Jika validasi gagal, kembali ke halaman pembuatan dengan pesan kesalahan
            return redirect()->back()->withInput()->with('error', 'Harap isi semua kolom dengan benar.');
        }

        // Memproses unggah gambar
        $design = $this->request->getFile('design');
        $design->move(ROOTPATH . 'public/uploads');

        // Simpan data pesanan ke database
        $data = [
            'product' => $this->request->getPost('product'),
            'material' => $this->request->getPost('material'),
            'quantity' => $this->request->getPost('quantity'),
            'design' => $design->getName()
        ];

        $this->orderModel->insert($data);

        // Redirect kembali ke halaman index dengan pesan sukses
        return redirect()->to('/order')->with('success', 'Pesanan berhasil dibuat.');
    }

    // Metode lain seperti edit, update, dan delete tetap tidak berubah
}
