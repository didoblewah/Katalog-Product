<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css')?>">
    <style>
        /* Tambahkan gaya khusus untuk upload file di sini */
        body {
            background-color: #0E448C;
            color: white;
        }

        .dropzone {
            border: dashed 4px #ddd !important ;
            background-color: #f2f6fc;
            border-radius: 1px;
        }
    
        .dropzone .dropzone-container {
            padding: rem 2;
            width: 400px;
            height: 200px;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: #8c96b2;
            z-index: 20;
        }
    
        .dropzone .file-input {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            opacity: 20%;
            visibility: hidden;
            cursor: pointer;
        }

        .file-icon{
            font-size: 60px;
    
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#" style="display: flex; align-items: center;">
            <!-- Menampilkan logo -->
            <img src="images/<?= $logo ?>" class="img-fluid" style="max-height: 30px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-0 mb-lg-2">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('about') ?> " style="font-size: 21px; color: black;">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('materials') ?>" style="font-size: 21px; color: black;">Materials</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('order') ?>" style="font-size: 21px; font-weight: 600; color: Black;">Order</a>
                </li>
                <a class="nav-link" href="<?= base_url('product') ?>" style="font-size: 21px; color: Black;">Contact Us</a> <!-- Tautan menu untuk produk -->
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
</nav>
<div class="container mt-5">
    <h2 class="text-center mb-4">Place Your Order</h2>
    <div class="row justify-content-center">
        <div class="col-md-3">
        <!-- Your HTML form for creating orders -->
            <form action="<?= base_url('order/store') ?>" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="product" class="form-label">Product</label>
                    <input type="text" class="form-control" id="product" name="product">
                </div>
                <div class="mb-3">
                    <label for="material" class="form-label">Material</label>
                    <input type="text" class="form-control" id="material" name="material">
                </div>
                <div class="mb-3">
                    <label for="quantity" class="form-label">Quantity</label>
                    <input type="number" class="form-control" id="quantity" name="quantity">
                </div>
                <div class="mb-3">
                    <label for="design" class="form-label">Upload Design</label>
                    <input type="file" class="form-control" id="design" name="design">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>

            </div>
            <div class="col-md-5 mt-2">
                <!-- Tambahkan UI upload file di sini -->
                <div class="mb-3 d-flex align-items-start flex-column">
                    <label for="design" class="mb-3">Upload Design</label>
                    <div class="dropzone mb-3">
                        <label for="files" class="dropzone-container">
                            <div class="file-icon"><img src="<?= base_url('images/upload.png') ?>" alt="Upload Icon" class="img-fluid" style="width: 100px; height: 100px;"></div>
                            <div class="text-center pt-3 px-5">
                                <p class="w-80 h8 text-dark fw-bold">Drag your documents, photos jpg.png.svg</p>
                            </div>
                        </label>
                        <input id="files" name="files[]" type="file" class="file-input" />
                    </div>
                </div>
                <div class="mb-3 d-flex align-items-center justify-content-end">
                    <p class="mb-0 me-2">Or ask on WhatsApp</p>
                    <a href="https://api.whatsapp.com/send?phone=081288393432" target="_blank" class="btn btn-success" style="margin-left: 10px;">
                        <img src="<?= base_url('images/whatsapp.png') ?>" alt="WhatsApp Logo" style="width: 30px; height: 30px; margin-right: 5px;">
                        Chat Now
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?= base_url('js/bootstrap.bundle.min.js')?>"></script>
</body>
</html>
