<!-- views/orders/index.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Order List</h2>
        <?php if(session()->getFlashdata('success')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Product Name</th>
                    <th>Material</th>
                    <th>Quantity</th>
                    <th>Design</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($orders): ?>
                    <?php foreach($orders as $order): ?>
                        <tr>
                            <td><?= $order['id'] ?></td>
                            <td><?= $order['product_name'] ?></td>
                            <td><?= $order['material'] ?></td>
                            <td><?= $order['quantity'] ?></td>
                            <td><img src="<?= base_url('uploads/'.$order['design']) ?>" style="max-width: 10000px;"></td>
                            <td>
                                <a href="<?= base_url('order/edit/'.$order['id']) ?>" class="btn btn-sm btn-primary">Edit</a>
                                <a href="<?= base_url('order/delete/'.$order['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this order?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No orders found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
