<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Materials</title>
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css')?>">
    <style>
        /* Reset margin dan padding */
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            font-family: Arial, sans-serif; /* Menggunakan jenis font Arial atau sans-serif */
        }

        /* Atur ukuran gambar */
        .product-image-container {
            position: relative; /* Posisi relatif untuk kontainer gambar */
            width: 100%;
            height: auto;
        }

        .product-image {
            width: 100%;
            height: auto;
            transition: filter 0.3s ease; /* Animasi perubahan filter saat hover */
        }

        /* Efek hover pada gambar */
        .product-image:hover {
            filter: brightness(70%); /* Menggelapkan gambar saat hover */
        }

        /* Atur teks di tengah */
        .product-name {
            position: absolute; /* Posisi absolut untuk teks */
            top: 50%; /* Posisi vertikal ke tengah */
            left: 50%; /* Posisi horizontal ke tengah */
            transform: translate(-50%, -50%); /* Geser teks ke tengah */
            color: white; /* Warna teks */
            font-size: 20px; /* Ukuran teks */
            font-weight: bold; /* Ketebalan teks */
            text-align: center; /* Pusatkan teks */
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); /* Bayangan teks */
            z-index: 1; /* Menempatkan teks di depan gambar */
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#" style="display: flex; align-items: center;">
                <!-- Menampilkan logo -->
                <img src="images/<?= $logo ?>" class="img-fluid" style="max-height: 40px;">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-3">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('about') ?> " style="font-size: 21px;">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('materials') ?>" style="font-size: 21px;font-weight: 600;">Materials</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('order') ?>" style="font-size: 21px;">Order</a>
                    </li>
                    <a class="nav-link" href="<?= base_url('product') ?>" style="font-size: 21px;">Contact Us</a> <!-- Tautan menu untuk produk -->
                </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>
<div class="container mt-0">
    <div class="row row-cols-1 row-cols-md-4 g-0">
        <?php foreach ($products as $product) : ?>
        <div class="col">
            <div class="product-image-container">
                <a href="<?= $product['link'] ?>"> <!-- Tautan untuk mengarahkan ke halaman detail produk -->
                    <img src="<?= base_url('images/' . $product['image']) ?>" class="product-image" alt="">
                    <div class="product-name"><?= $product['name'] ?></div>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<script src="<?= base_url('js/bootstrap.bundle.min.js')?>"></script>
</body>
</html>