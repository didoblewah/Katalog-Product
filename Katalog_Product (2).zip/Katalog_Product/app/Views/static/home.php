<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css')?>">
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#" style="display: flex; align-items: center;">
                <!-- Menampilkan logo -->
                <img src="<?= base_url('images/' . $logo) ?>" class="img-fluid" style="max-height: 40px;">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-3">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('about') ?>" style="font-size: 21px; font-weight: 600;">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('materials') ?>" style="font-size: 21px;">Materials</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('order/create') ?>" style="font-size: 21px;">Order</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('product') ?>" style="font-size: 21px;">Contact Us</a> <!-- Tautan menu untuk produk -->
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('login') ?>" style="font-size: 21px;">Login</a>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>
    
    <!-- Carousel -->
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php foreach ($carouselImages as $index => $image) : ?>
                <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                    <img class="d-block w-100" src="<?= base_url('images/' . $image) ?>" alt="Slide <?= $index + 1 ?>">
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- About Us -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <div class="about-box">
                    <h2 style="font-size: 70px;">About Us</h2>
                    <p style="font-size:20px;"> Its finest merupakan penyedia jasa produksi pakaian (Konveksi).
                        Sesuai namanya itsfinest yang artinya yang terbaik, maka kualitas & pelayanan akan kami utamakan.
                        Itsfinest, finest quality, finest service.
                    </p>
                </div>
            </div>
            <div class="col-md-6">
                <!-- Isi Produk -->
            </div>
        </div>
    </div>

    <!-- CSS -->
    <style>
        .about-box {
            background-color: #f0f0f0;
            padding: 50px;
            border: 2px solid #ccc;
            border-radius: 5px;
            width: 200%;
            margin: 0;
        }
    </style>

    <!-- Foto Produk -->
    <div class="container mt-3">
        <div class="row">
            <?php foreach ($products as $product) : ?>
                <div class="col-md-4">
                    <img src="<?= base_url('images/' . $product['image']) ?>" alt="<?= $product['name'] ?>" class="img-fluid product-image">
                    <p><?= $product['description'] ?></p>
                    <a href="<?= $product['link'] ?>" class="btn btn-primary">See Details</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Spasi Kosong -->
    <div style="height: 1000px;"></div>

    <!-- Copyright -->
    <footer class="footer mt-auto py-3">
        <div class="container">
            <span class="text-muted">Copyright@Itsfinest.Vendor 2023</span>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="<?= base_url('js/bootstrap.bundle.min.js')?>"></script>
</body>
</html>
