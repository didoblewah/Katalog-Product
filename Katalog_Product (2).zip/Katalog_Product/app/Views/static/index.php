<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css')?>">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h2 class="mb-4">Order List</h2>
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
            <?php endif; ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Material</th>
                        <th>Quantity</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($orders as $order): ?>
                        <tr>
                            <td><?= $order['id'] ?></td>
                            <td><?= $order['product_name'] ?></td>
                            <td><?= $order['material'] ?></td>
                            <td><?= $order['quantity'] ?></td>
                            <td>
                                <a href="<?= base_url('order/edit/'.$order['id']) ?>" class="btn btn-sm btn-primary">Edit</a>
                                <a href="<?= base_url('order/delete/'.$order['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this order?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="<?= base_url('js/bootstrap.bundle.min.js')?>"></script>
</body>
</html>
