<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order</title>
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('css/orrd.css') ?>">
</head>
<body>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <h2 class="mb-4">Edit Order</h2>
            <?php if(session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>
            <form action="<?= base_url('order/update/'.$order['id']) ?>" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="product_name" class="form-label">Product Name</label>
                    <input type="text" class="form-control form-control-lg" id="product_name" name="product_name" value="<?= $order['product_name'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="material" class="form-label">Material</label>
                    <input type="text" class="form-control form-control-lg" id="material" name="material" value="<?= $order['material'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="quantity" class="form-label">Quantity</label>
                    <input type="number" class="form-control form-control-lg" id="quantity" name="quantity" value="<?= $order['quantity'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="design" class="form-label">Upload Design</label>
                    <input type="file" class="form-control form-control-lg" id="design" name="design">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</div>
<script src="<?= base_url('js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
