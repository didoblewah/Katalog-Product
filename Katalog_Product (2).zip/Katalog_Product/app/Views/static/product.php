<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Products</title>
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css')?>">
    <style>
        /* CSS tambahan untuk styling */
        .product-container {
            margin-top: 50px;
        }
        .product-card {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .product-card img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        .product-card p {
            font-size: 16px;
        }
        .product-card a.btn {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <!-- Navbar content -->
    </nav>

    <div class="container">
        <h1 class="text-center mt-5">Our Products</h1>
        <div class="row product-container">
            <?php foreach ($products as $product) : ?>
                <div class="col-md-4">
                    <div class="product-card">
                        <img src="<?= base_url('images/' . $product['image']) ?>" alt="Product Image">
                        <p><?= $product['description'] ?></p>
                        <a href="<?= $product['link'] ?>" class="btn btn-primary">See Details</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="<?= base_url('js/bootstrap.bundle.min.js')?>"></script>
</body>
</html>
