<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Material Detail</title>
    <style>
        /* Reset margin dan padding */
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            font-family: Arial, sans-serif; /* Menggunakan jenis font Arial atau sans-serif */
        }

        /* Atur ukuran gambar */
        .product-image-container {
            width: 100%;
            height: 60vh; /* Setengah tinggi viewport */
            overflow: hidden; /* Menyembunyikan bagian gambar yang melebihi container */
            position: relative; /* Mengatur posisi relatif untuk child elements */
        }

        .product-image {
            width: 100%; /* Lebar gambar menyesuaikan container */
            height: auto; /* Tinggi gambar menyesuaikan lebar */
            object-fit: cover; /* Mengisi container tanpa merubah aspek gambar */
            filter: brightness(80%); /* Efek gelap sebesar 20% */
        }

        /* Atur teks di tengah kiri */
        .product-name {
            position: absolute; /* Mengatur posisi absolut untuk teks */
            top: 50%; /* Menempatkan teks di tengah vertikal */
            left: 20px; /* Menempatkan teks di kiri */
            transform: translateY(-50%); /* Menyesuaikan teks ke tengah vertikal */
            color: white; /* Warna teks */
            font-size: 24px; /* Ukuran teks */
            font-weight: bold; /* Ketebalan teks */
            z-index: 1; /* Menempatkan teks di atas gambar */
        }
    </style>
</head>

<body>
<div class="product-image-container">
    <img src="<?= base_url('images/' . $product['image']) ?>" class="product-image" alt="">
    <div class="product-name"><?= $product['name'] ?></div>
</div>
</body>
</html>
